from __future__ import absolute_import

# Note: The following import statement is defined in order to resolve
# the conflict of the module names between 'ryu.lib.ovs' and 'ovs'.
# The latter is the official Python package of Open vSwitch.
import ovs
