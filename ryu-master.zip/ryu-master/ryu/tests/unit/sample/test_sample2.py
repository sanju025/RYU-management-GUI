# vim: tabstop=4 shiftwidth=4 softtabstop=4

import unittest
from nose.tools import ok_, eq_
# from ryu.app.simple_switch import SimpleSwitch


class TestSample2(unittest.TestCase):

    def testS2Func1(self):
        ok_(True)

    def testS2Func2(self):
        ok_(True)
