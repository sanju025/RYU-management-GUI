*************************
Built-in Ryu applications
*************************

Ryu has some built-in Ryu applications.
Some of them are examples.
Others provide some functionalities to other Ryu applications.

.. toctree::
   :maxdepth: 1

   app/ofctl.rst
   app/ofctl_rest.rst
   app/rest_vtep.rst
